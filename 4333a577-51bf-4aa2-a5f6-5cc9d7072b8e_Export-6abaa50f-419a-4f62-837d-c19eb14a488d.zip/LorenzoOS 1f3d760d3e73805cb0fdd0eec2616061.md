# LorenzoOS

> “strive for **progress**, not **perfection**.”
- Someone, sometime
> 

[https://widgetbox.app/embed/life/progress/0fc6a232-3b74-4d4e-a11b-91a4ec6c50e1](https://widgetbox.app/embed/life/progress/0fc6a232-3b74-4d4e-a11b-91a4ec6c50e1)

[https://widgetbox.app/embed/time/until/5fecea12-a40a-4776-94a3-2b52c18e48a3](https://widgetbox.app/embed/time/until/5fecea12-a40a-4776-94a3-2b52c18e48a3)

### navigation menu

---

<aside>
<img src="https://www.notion.so/icons/compose_gray.svg" alt="https://www.notion.so/icons/compose_gray.svg" width="40px" />  **notes:**

seals

</aside>

---

[to do](to%20do%201f3d760d3e73810c9ad2c0a3f6999998.csv)